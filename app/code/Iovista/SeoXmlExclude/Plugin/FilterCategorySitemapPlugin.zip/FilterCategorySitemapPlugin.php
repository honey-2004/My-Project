<?php
namespace Iovista\SeoXmlExclude\Plugin;

class FilterCategorySitemapPlugin
{
    public function afterGetCollection(
        \Magento\Sitemap\Model\ResourceModel\Catalog\Category $subject,
        $result
    ) {
        foreach ($result as $key => $category) {
            if (!empty($category['exclude_from_xml_sitemap'])) {
                unset($result[$key]);
            }
        }
        return $result;
    }
}
