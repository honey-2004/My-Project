<?php
/**
 * Three Action Buttons Block
 */
namespace Iovista\Fms\Block;

use Magento\Framework\View\Element\Template;

class ThreeActionButtons extends Template
{
    /**
     * Get YouTube URL
     *
     * @return string
     */
    public function getYouTubeUrl()
    {
        return $this->getData('youtube_url') ?: '#';
    }

    /**
     * Get Articles URL
     *
     * @return string
     */
    public function getArticlesUrl()
    {
        return $this->getData('articles_url') ?: '#';
    }

    /**
     * Get Catalog URL
     *
     * @return string
     */
    public function getCatalogUrl()
    {
        return $this->getData('catalog_url') ?: '#';
    }

    /**
     * Get current date
     *
     * @return string
     */
    public function getCurrentDate()
    {
        return date('F j, Y');
    }

    /**
     * Get social media URLs
     *
     * @return array
     */
    public function getSocialUrls()
    {
        return [
            'twitter' => $this->getData('twitter_url') ?: '#',
            'facebook' => $this->getData('facebook_url') ?: '#',
            'reddit' => $this->getData('reddit_url') ?: '#',
            'linkedin' => $this->getData('linkedin_url') ?: '#'
        ];
    }
}

